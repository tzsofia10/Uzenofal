document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("messageForm").onsubmit = function (e) {
        e.preventDefault();
        
        // HTML elemek összegyűjtése és változókban tárolása
        let name = document.getElementById("name").value;
        let message = document.getElementById("message").value;
        let image = document.getElementById("image").files[0]; // Képfájl kiválasztása
        console.log(name, message, image);
        if (message.trim() === "") {
            // Hibaüzenet megjelenítése, ha az üzenet mező üres
            alert("Az üzenet mező kitöltése kötelező.");
            return;
        }

        let formData = new FormData();
        formData.append("name", name);
        formData.append("content", message);
        
        // Ha van kép, adjuk hozzá a formData-hoz
        if (image) {
            formData.append("image", image);
        }

        fetch("backend/message-process.php", {
            method: "POST",
            body: formData
        }).catch(error => console.error("Hiba a JSON parse-olásakor vagy a fetch során:", error))
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.success) {
                loadMessages();
                document.getElementById("name").value = "";
                document.getElementById("message").value = "";
                document.getElementById("image").value = "";
            } else {
                alert("Hiba történt az üzenet elküldésekor.");
            }
        });
    };
    loadMessages();
});

function loadMessages() {
    fetch("backend/get-messages.php")
        .then(response => response.json())
        .then(data => {
            // Üzenetek konténer frissítése
            let messagesContainer = document.getElementById("messages");
            messagesContainer.innerHTML = ""; // Tisztítás

            data.forEach(msg => {
                // Új div létrehozása üzenetkártyának
                let card = document.createElement("div");
                card.classList.add("message-card");
                
                // Beküldő neve
                let author = document.createElement("p");
                author.classList.add("author"); // author osztály hozzáadása
                author.textContent = msg.name;

                // Üzenet időpontja
                let timestamp = document.createElement("p");
                timestamp.classList.add("timestamp"); // timestamp osztály hozzáadása
                timestamp.textContent = `Beküldve: ${msg.created_at}`;

                // Üzenet tartalma
                let content = document.createElement("p");
                content.textContent = msg.content;

                // Ha van kép
                if (msg.image_path) {
                    let img = document.createElement("img");
                    img.src = "backend/" + msg.image_path;
                    img.classList.add("message-image");
                    card.appendChild(img);
                }

                // Ha az üzenet YouTube linket tartalmaz
                let youtubeId = extractYouTubeId(msg.content);
                if (youtubeId) {
                    let iframe = document.createElement("iframe");
                    iframe.width = 360;
                    iframe.height = 215;
                    iframe.src = "https://www.youtube.com/embed/" + youtubeId;
                    iframe.frameBorder = "0";
                    iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
                    iframe.allowFullscreen = true;
                    card.appendChild(iframe); // Itt adjuk hozzá az üzenetkártyához
                }

                // Az elemek hozzáadása az üzenetkártyához
                card.appendChild(author);
                card.appendChild(timestamp);
                card.appendChild(content);

                // Kártya hozzáadása az üzenetek konténeréhez
                messagesContainer.appendChild(card);
            });
        });
}

function extractYouTubeId(url) {
    const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
}
